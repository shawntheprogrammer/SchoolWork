1.  run command         hadoop jar top5.jar Top5FemaleRating input1 input2 out1 out2
2.  run command         hadoop jar top5.jar UserInfo input1 out3 anymovieid